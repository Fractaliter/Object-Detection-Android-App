# glass-defects > 2025-06-07 12:58pm
https://universe.roboflow.com/krzysztof-wawrzkiewicz-zj2l1/glass-defects-r4hil

Provided by a Roboflow user
License: CC BY 4.0

